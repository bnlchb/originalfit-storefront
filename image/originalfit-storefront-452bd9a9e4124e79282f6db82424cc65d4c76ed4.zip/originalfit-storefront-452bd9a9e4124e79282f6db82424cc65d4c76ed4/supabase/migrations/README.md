# Database migrations

Forward-only SQL for an **already-created** Supabase schema (`supabase/schema.sql`
is the one-shot, full-install script for new projects — never re-run it on a
database that has data).

## Convention

| Rule | Why |
| --- | --- |
| Filename `NNNN_<short_description>.sql`, applied in **ascending** numeric order | Order is the versioning |
| Each file changes **one thing** and is idempotent (re-running it is a no-op or clearly intentional) | Safe to re-paste after a retry |
| Never edit or re-run a migration that is already applied — add `NNNN+1` instead | Databases drift; versioning must not |
| Keep the `VERIFY` snippet at the bottom | Instant visual confirmation |

## How to apply

1. Supabase **Dashboard → SQL Editor** → paste the file's full contents → **Run**.
   (SQL Editor executes with service-role privileges, bypassing RLS — exactly
   what migrations need.)

## Applied so far

| # | File | Purpose |
| --- | --- | --- |
| 0001 | `0001_remove_demo_seed_products.sql` | Deletes the 10 placeholder seed products (catalog → live rows only) |
| 0002 | `0002_admin_console_rls.sql` | `profiles.is_admin` + `is_admin()` helper + admin console policies |
| 0003 | `0003_guest_checkout.sql` | Guest checkout: anon inserts for null-user orders + items |
| 0004 | `0004_secure_order_creation.sql` | All order creation moves behind a security-definer `create_order()` — server re-prices from `products`, no more anon/authenticated direct INSERT policies, `client_ref` idempotency |
| 0005 | `0005_fix_create_order_null_total.sql` | Fixes 23502 (total_amount NULL) from 0004: PL/pgSQL `SELECT…INTO` with no rows nulls the accumulators — re-init on miss + hardened concurrent-submit fallback |
| 0006 | `0006_admin_login_throttle.sql` | Server-side admin sign-in throttle: `admin_login_attempts` ledger (RLS ON, zero policies) + `admin_login_lock()` — 1/5/15/30/60-min locks after every 5 failures per identifier (24h window) + 10-min IP spray guard; a success wipes the key; passwords never stored |
| 0007 | `0007_admin_login_aggressive_ladder.sql` | Replaces the ladder with an aggressive per-attempt progression: every failed attempt locks immediately — 1m/5m/20m/20m/20m/20m/30m/1h/2h/6h/12h/24h (rows 4–6 clamped non-decreasing); expiry never resets; only a successful sign-in wipes; 7-day ledger horizon |
| 0008 | `0008_product_multi_images.sql` | Multi-photo products: `products.images` jsonb array (≤10 URLs per product, guard constraint), cover mirrored in `image_url` for cards/cart/orders; legacy single-photo rows auto-mirrored into the array; reuses the `product-images` bucket (no new RLS) |
| 0009 | `0009_sizes_per_size.sql` | Per-size stock: `product_sizes` table (six canonical sizes, public read / admin write), `order_items.size` (legacy rows default "M"), size-aware `create_order()` that enforces + atomically decrements per-size stock (`products.stock` fallback for products without size rows), and a trigger keeping `products.stock` = sum of its size rows |

## Changing the schema later

Prefer adding a `NNNN_*` file over rerunning `schema.sql`. If the change also
belongs in a fresh install, mirror the same change inside `supabase/schema.sql`.
